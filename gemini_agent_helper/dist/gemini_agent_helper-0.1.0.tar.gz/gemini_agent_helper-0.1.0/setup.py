from setuptools import setup, find_packages

setup(
    name='gemini_helper',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'python-dotenv',
        'openai-agent-sdk',
        'click' 
    ],
    description='Gemini SDK helper with OpenAI Agent SDK',
    author='Huriya Syed',
    entry_points={  
        'console_scripts': [
            'gemini-helper=gemini_helper.cli:main',
        ],
    },
)
